/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9fxmlcpumonitor;

import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * References:
 * 
 *      Lines: 98,99,128,129,156,162 - https://stackoverflow.com/questions/55381172/how-to-change-color-of-buttons-made-from-scene-builder
 *      CPU method, Line Chart code, and timeline initialization used from Professor Wergeles' starter code and the pdf for this challenge
 * 
 * 
 * @author rthak
 */
public class Rntgb9FXMLCPUMonitorController implements Initializable {
    
    @FXML
    private AnchorPane root;
    
    @FXML
    private Button startStop;
    
    @FXML
    private Button recordReset;
    
    @FXML
    public Timeline timeline;
    
    @FXML
    private static double cpu = 0;
    
    @FXML
    private double cpuPercent = 0;
    
    @FXML
    public ImageView handImageView;
    
    @FXML
    public Label digitalDisplay;
    
    @FXML
    public int recordCounter = 0;
    
    @FXML
    public double rotation = 210;
    
    @FXML
    public float currCPUUsage = 0;
   
    @FXML
    private LineChart<String, Number> lineChart;
    
    @FXML
    private CategoryAxis xAxis;
    
    @FXML
    private NumberAxis yAxis;
   
    @FXML
    private XYChart.Series<String, Number> series;
    

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        series = new XYChart.Series();
        lineChart.getData().add(series);
        
        startStop.setStyle("-fx-background-color: #5dbcd2");
        recordReset.setStyle("-fx-background-color: #5dbcd2");
        
        timeline = new Timeline(new KeyFrame(Duration.millis(100), (ActionEvent) -> {
            cpu = this.getCPUUsage();
            cpuPercent = cpu*100;
            
            rotation = 210 + (cpuPercent*3);                                    //210 degrees is starting pt. gauge spans 300 degrees so each percent = 3 degrees
            handImageView.setRotate(rotation);

            digitalDisplay.setText(String.format("%.2f", cpuPercent) + "%");
        }));
        
        timeline.setCycleCount(Animation.INDEFINITE);
    }  
    
    @FXML
    private void handleRecordReset(ActionEvent event){
        if(handImageView.getRotate() == 210)
        {
            recordReset.setText("Record");
        }
        else if(!isRunning())
        {
            recordReset.setText("Record");
            handImageView.setRotate(210);
            digitalDisplay.setText("0.00%");
            recordCounter = 0;
            series.getData().clear();
            lineChart.getData().clear();
            startStop.setStyle("-fx-background-color: #5dbcd2");
            recordReset.setStyle("-fx-background-color: #5dbcd2");
        }
        else
        {
            recordReset.setText("Record");
            recordCounter++;
            currCPUUsage = (float)cpuPercent;
            series.getData().add(new XYChart.Data(Integer.toString(recordCounter), currCPUUsage));
        }
    }
    
    @FXML
    public void handleOpen(ActionEvent event){
        FileChooser fileChooser = new FileChooser();
        
        Stage stage = (Stage) root.getScene().getWindow();
        
        fileChooser.showOpenDialog(stage);
    };
    
    @FXML
    public void handleStartStop(ActionEvent event){
    
        if(isRunning())
        {
            timeline.pause();
            startStop.setText("Start");
            startStop.setStyle("-fx-background-color: #13ea6b");
            recordReset.setText("Reset");
        }
        else
        {
            timeline.play();
            startStop.setStyle("-fx-background-color: #f53f3f");
            startStop.setText("Stop");
            recordReset.setText("Record");
        }
    }

    public boolean isRunning()
    {
        if(timeline != null)
        {
            if(timeline.getStatus() == Animation.Status.RUNNING)
            {
                return true;
            }
        }
        return false;    
    }
    
    public double getCPUUsage() {
        OperatingSystemMXBean operatingSystemMXBean = ManagementFactory.getOperatingSystemMXBean();
        double value = 0;
        
        for(Method method : operatingSystemMXBean.getClass().getDeclaredMethods()) {
            method.setAccessible(true);
            
            if (method.getName().startsWith("getSystemCpuLoad") && Modifier.isPublic(method.getModifiers())) {
                try {
                    value = (double) method.invoke(operatingSystemMXBean);
                } catch (Exception e) {
                    value = 0;
                }
                return value;
            }
        }
        return value;
    }
}
