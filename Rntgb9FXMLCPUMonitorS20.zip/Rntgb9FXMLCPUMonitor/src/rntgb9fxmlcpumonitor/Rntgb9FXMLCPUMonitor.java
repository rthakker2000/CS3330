/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9fxmlcpumonitor;

import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;


/**
 *
 * @author rthak
 */
public class Rntgb9FXMLCPUMonitor extends Application {
       
   public Timeline timeline;
      
    @Override
    public void start(Stage primaryStage) throws Exception{
        
        Parent root = FXMLLoader.load(getClass().getResource("Rntgb9FXMLCPUMonitor.fxml"));
                
        Scene scene = new Scene(root, 600, 475); 
        
        primaryStage.setTitle("CPU Monitor Starter Code"); 
        primaryStage.setScene(scene); 
        primaryStage.show(); 
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}