/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// using SendGrid's Java Library
// https://github.com/sendgrid/sendgrid-java

package rntgb9noteslist;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.web.HTMLEditor;

/**
 * FXML Controller class
 *      open button on menu brings user to this scene. Can read the .txt file. Can delete, return to menu, or edit. Edit will take user
 *                  to the new Note FXML and controller
 *
 * References:
 *      Lines: 91 - 92 : https://stackoverflow.com/questions/43236082/javafx-elements-change-the-size-dynamically-in-relationship-to-the-size-of-the
 *      Lines 104 - 108 : https://code.makery.ch/blog/javafx-dialogs-official/
 * 
 * @author rthak
 */
public class ReadNoteFXMLController extends Switchable implements Initializable {

    @FXML
    AnchorPane readRoot;
    
    @FXML
    TextField titleField;
    
    @FXML
    HTMLEditor noteArea;
    
    @FXML
    private Button returnButton;
    
    @FXML
    private Button editButton;
    
    @FXML
    private Button deleteButton;
    
    @FXML
    private Button helpButton;
    
    @FXML
    private Button shareButton;
    
    @FXML
    VBox editorContainer;
    
    NoteModel note;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        LoginPageFXMLController controller = (LoginPageFXMLController) getControllerByName("LoginPageFXML");
        note = controller.note; 
    }    
    
    @FXML
    void handleReturn(ActionEvent event)
    {
        Switchable.switchTo("MenuFXML");
    }
    
    @FXML
    void handleEdit(ActionEvent event)
    {
        Switchable.switchTo("EditNoteFXML");
        
        EditNoteFXMLController controller = (EditNoteFXMLController) getControllerByName("EditNoteFXML");
                
        if (controller != null)
        {
            controller.titleField.setText(titleField.getText());

            controller.editor.setHtmlText(note.getFileInHTML());
            controller.editorContainer.prefHeightProperty().bind(controller.editRoot.getScene().getWindow().heightProperty());
            controller.editorContainer.prefWidthProperty().bind(controller.editRoot.getScene().getWindow().widthProperty());
        }
    }
    
    @FXML
    void handleDelete(ActionEvent event)
    {
        Alert a = new Alert(AlertType.CONFIRMATION);
        a.setHeaderText("Are you sure you want to delete this file?");
        a.setContentText("Please make sure you would like to delete this file. It cannot be recovered.");
        a.setTitle("Confim Deletion");
        
        ButtonType delete = new ButtonType("Delete");
        ButtonType cancel = new ButtonType("Cancel", ButtonData.CANCEL_CLOSE);
        a.getButtonTypes().setAll(delete, cancel);
        
        Optional<ButtonType> result = a.showAndWait();
        
        
        if (result.get() == delete)
        {
            note.deleteNote();
            Switchable.switchTo("MenuFXML");
        }
        else
        {
            System.out.println("File not deleted");
        }
    }
    
    @FXML
    private void handleHelp(ActionEvent event)
    {
        Switchable.switchTo("HelpFXML");
        HelpFXMLController controller = (HelpFXMLController) getControllerByName("HelpFXML");
        controller.key = 2;
    }
    
    @FXML
    private void handleShare(ActionEvent event) throws IOException 
    {
        Switchable.switchTo("ShareNoteFXML");
    }     
}

