/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9noteslist;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

/**
 * FXML Controller class
 *
 * @author rthak
 */
public class HelpFXMLController extends Switchable implements Initializable {

    @FXML
    private Button returnButton;
    
    @FXML
    private TextArea helpInfo;
    
    @FXML
    protected int key = 0;                      //key determines what page the user should be returned to, default is to return to menu
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        helpInfo.setText("Hello! My name is Rushil Thakker. I am a sophomore in CS3330: Object Oriented Prgramming and this is my Final Project!\n\n"
                + " For my final project, I decided to create a Notes app. When starting the app, you start in the Login Page. From here, you can either"
                + " use the default login (Username = 'User1' , Password = 'letmein') to continue or create an account. Clicking on create an account will"
                + " take you to a new page where you enter in a username and password. Then you are returned to the login page where you can login using your"
                + " new credentials. \n\nFrom here you choose a directory to store all of your notes. 'Choose This As Your Directory To Start!' is a pre-loaded"
                + " directory with test files. This is avaiable in the source of this project. \n\nNext, there is a menu where you can open a previously created"
                + " note or create a new note. When opening a note, it is opened in a read only mode. It can be edited or deleted or shared. If you share the note"
                + " you will be taken to a page where you can enter an email address and an email will be sent to that person with your note. Editing takes you to the same"
                + " page that creating a new note will. On this page you can save or delete the file. From every page you can return the the prevous one or get to"
                + " this help message\n\n***NOTE:: Talked to Professor Wergeles about the CSS Warnings that appear and he said that it's okay if I'm unable to fix them");
    }   
    
    
    @FXML
    private void handleReturn(ActionEvent event)
    {
        switch (key) {
            case 0:
                Switchable.switchTo("MenuFXML");
                break;
            case 1:
                Switchable.switchTo("LoginPageFXML");
                break;
            case 2:
                Switchable.switchTo("ReadNoteFXML");
                break;
            case 3:
                Switchable.switchTo("EditNoteFXML");
                break;
            case 4:
                Switchable.switchTo("CreateUserFXML");
                break;
            case 5:
                Switchable.switchTo("ShareNoteFXML");
                break;
            default:
                break;
        }
    }
}
