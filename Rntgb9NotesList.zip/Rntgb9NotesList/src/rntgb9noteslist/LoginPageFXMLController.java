/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9noteslist;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author rthak
 */
public class LoginPageFXMLController extends Switchable implements Initializable {

    @FXML
    private AnchorPane anchorRoot;
    
    @FXML
    private TextField username;
    
    @FXML
    private PasswordField password;
    
    @FXML
    private Button loginButton;
    
    @FXML
    private HBox passwordHintBox;
    
    @FXML
    private Text passwordHintText1;
    
    @FXML
    private Text passwordHintText2;
    
    @FXML
    private Button helpButton;
    
    @FXML
    private Button createUser;
    
    NoteModel note;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            // TODO
            
            note = new NoteModel();
        } catch (IOException ex) {
            Logger.getLogger(LoginPageFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    
    @FXML
    private void handleLogin(ActionEvent event) throws IOException
    {
        if (note.isUserInHash(username.getText()))
        {
            if (note.isPassInHash(password.getText()))
            {
                Stage stage = (Stage) anchorRoot.getScene().getWindow(); 
                DirectoryChooser directoryChooser = new DirectoryChooser();
                directoryChooser.setInitialDirectory(new File("src"));
                note.setSelectedDirectory(directoryChooser.showDialog(stage));
            
                if(note.getSelectedDirectory() == null)
                {
                    Switchable.switchTo("LoginPageFXML");
                    Alert a = new Alert(Alert.AlertType.ERROR);
                    a.setContentText("Directory not found. Please choose a valid directory!");
                    a.setHeaderText("DIRECTORY NOT FOUND");
                    a.show();
                    return;
                }       
            
                note.setDirectoryFilePath(note.getSelectedDirectory().toString());
                Switchable.switchTo("MenuFXML");
            }
            
            else
            {
                passwordHintBox.setOpacity(1.00);
                passwordHintText1.setText("Default Login: ");
                passwordHintText2.setText("Username: User1 Password: letmein");
            }
        }
        
        else
        {
            passwordHintBox.setOpacity(1.00);
            passwordHintText1.setText("Username doesn't exist! Please create an account!");
            passwordHintText2.setText("Default Login: Username: User1 Password: letmein");
        }
    }
    
    @FXML
    private void handleHelp(ActionEvent event)
    {
        Switchable.switchTo("HelpFXML");
        HelpFXMLController controller = (HelpFXMLController) getControllerByName("HelpFXML");
        controller.key = 1;
    }
    
    @FXML
    private void handleCreateUser(ActionEvent event)
    {
        Switchable.switchTo("CreateUserFXML");
    }
}
