/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9noteslist;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author rthak
 */
public class CreateUserFXMLController extends Switchable implements Initializable {

    @FXML
    private Button helpButton;
    
    @FXML
    private Button returnButton;
    
    @FXML
    private Button createUser;
    
    @FXML
    private TextField username;
    
    @FXML
    private PasswordField password;
    
    @FXML
    private PasswordField passwordConfirm;
    
    @FXML
    private Label passwordsMatchWarning;
    
    @FXML
    private Label usernameTakenWarning;
    
    @FXML
    private Label allFieldsFilledOut;
    
    NoteModel note;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        LoginPageFXMLController controller = (LoginPageFXMLController) getControllerByName("LoginPageFXML");
        note = controller.note;  
    }    
    
    @FXML
    private void handleReturn(ActionEvent event)
    {
        username.setText("");
        password.setText("");
        passwordConfirm.setText("");
        Switchable.switchTo("LoginPageFXML");
    }
    
    @FXML
    private void handleHelp(ActionEvent event)
    {
        Switchable.switchTo("HelpFXML");
        HelpFXMLController controller = (HelpFXMLController) getControllerByName("HelpFXML");
        controller.key = 4;
    }
    
    @FXML
    private void handleCreateUser(ActionEvent event)
    {
        if (!username.getText().equals("") && !password.getText().equals("") && !passwordConfirm.getText().equals(""))
        {
            if(!note.isUserInHash(username.getText()))
            {
                if(password.getText().equals(passwordConfirm.getText()))
                {
                    note.setNewLoginInfo(username.getText(), passwordConfirm.getText());
                    Alert a = new Alert(Alert.AlertType.INFORMATION);
                    a.setHeaderText("USER CREATED");
                    a.setContentText("User was successfully created! Please Login with you credentials to continue!");
                    a.show();
                    note.writeToFile();
                    username.setText("");
                    password.setText("");
                    passwordConfirm.setText("");
                    Switchable.switchTo("LoginPageFXML");
                }
                else
                {
                    passwordsMatchWarning.setOpacity(1.00);
                }
            }
            
            else
            {
                usernameTakenWarning.setOpacity(1.0);
            }
        }
        
        else
        {
            allFieldsFilledOut.setOpacity(1.00);
        }
    } 
}
