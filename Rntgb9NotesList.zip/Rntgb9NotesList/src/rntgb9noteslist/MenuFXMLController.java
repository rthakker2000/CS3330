/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9noteslist;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * Menu Controller, the user can add Note which switches to the new Note FXML/Controller or open a note which switches to ReadNote FXML/Controller
 * 
 * References:
 *      Lines 113 - 114 : https://stackoverflow.com/questions/43236082/javafx-elements-change-the-size-dynamically-in-relationship-to-the-size-of-the
 * 
 * @author rthak
 */
public class MenuFXMLController extends Switchable implements Initializable {

    
    @FXML
    public AnchorPane paneRoot;
    
    @FXML
    private Button addNote;
    
    @FXML
    private Button openNote;
    
    @FXML
    private Button helpButton;
    
    NoteModel note;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        LoginPageFXMLController controller = (LoginPageFXMLController) getControllerByName("LoginPageFXML");
        note = controller.note; 
    }    
    
    public void handleOpen(ActionEvent event) throws IOException
    {        
        
        Stage stage = (Stage) paneRoot.getScene().getWindow(); 
        
        FileChooser fileChooserOpen = new FileChooser(); 
        fileChooserOpen.setInitialDirectory(note.getSelectedDirectory());
        fileChooserOpen.getExtensionFilters().add(
        new FileChooser.ExtensionFilter("Text files", "*.txt"));
        
        note.setFile(fileChooserOpen.showOpenDialog(stage));
        
        Switchable.switchTo("ReadNoteFXML");
                
        ReadNoteFXMLController controller = (ReadNoteFXMLController) getControllerByName("ReadNoteFXML");
                                                
        BufferedReader br = null;
        
        if(note.getFile() == null)
        {
            Switchable.switchTo("MenuFXML");
            Alert a = new Alert(AlertType.ERROR);
            a.setContentText("File not found, please try opening another file");
            a.setHeaderText("FILE NOT FOUND");
            a.show();
            return;
        }
        
        
        try {
            br = new BufferedReader(new FileReader(note.getFile()));
        } catch (FileNotFoundException ex) {
             Logger.getLogger(MenuFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if (controller != null)
        {
            String textInFile;
            controller.titleField.setText(note.getFile().getName());
            
            try {
                                
                while ((textInFile = br.readLine()) != null)
                {
                    note.setFileStringHTML(textInFile);
                    controller.noteArea.setHtmlText(textInFile);  
                }
                
                controller.editorContainer.prefHeightProperty().bind(controller.readRoot.getScene().getWindow().heightProperty());
                controller.editorContainer.prefWidthProperty().bind(controller.readRoot.getScene().getWindow().widthProperty());
                
                br.close();
            } catch (IOException ex) {
                Logger.getLogger(MenuFXMLController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
            
    @FXML
    private void handleGoToToDoItem(ActionEvent event)
    {
        Switchable.switchTo("EditNoteFXML");
    }
    
    @FXML
    private void handleHelp(ActionEvent event)
    {
        Switchable.switchTo("HelpFXML");
        HelpFXMLController controller = (HelpFXMLController) getControllerByName("HelpFXML");
        controller.key = 0;
    }
}
