/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9noteslist;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * References:
 *      Lines 55 - 65 : https://www.javacodeexamples.com/read-text-file-into-hashmap-in-java-example/2333
 *      Lines 148 -152 : https://www.javacodeexamples.com/write-hashmap-to-text-file-in-java-example/2353
 * 
 * @author rthak
 */
public class NoteModel implements NoteInterface{
    
    private File file;
    private File selectedDirectory;
    private String directoryFilePath;
    private String fileInHTML;
    private HashMap<String, String> loginInfo = new HashMap<>(); 
    private File loginInfoFile = new File("src/LoginInfo.txt");
            
    public NoteModel() throws IOException
    {    
        loadFile();
    }
    
    private void loadFile() throws IOException
    {
        loginInfoFile = new File("src/LoginInfo.txt");
        BufferedReader br = null;
        loginInfo.put("User1", "letmein");
        
        try {
            br = new BufferedReader(new FileReader(loginInfoFile));
        } catch (FileNotFoundException ex) {
            Logger.getLogger(NoteModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String line;
        
        while((line = br.readLine()) != null)
        {
            String[] parts = line.split(":");
            
            String username = parts[0].trim();
            String password = parts[1].trim();
            
            if (!username.equals("") && !password.equals(""))
            {
                loginInfo.put(username, password);
            }
        }
        
        br.close();    
    }
    
    @Override
    public void deleteNote()
    {   
        if(file.delete())
        {
            System.out.println("File deleted");
            file = null;
        }
        else
        {
            System.out.println("Else");
        }
    }
   
    void setFile(File file)
    {
        this.file = file;
    }
    
    File getFile()
    {
        return file;
    }
    
    void setSelectedDirectory(File file)
    {
        this.selectedDirectory = file;
    }
    
    File getSelectedDirectory()
    {
        return selectedDirectory;
    }
    
    void setDirectoryFilePath(String string)
    {
        this.directoryFilePath = string;
    }
    
    String getDirectoryFilePath()
    {
        return directoryFilePath;
    }
    
    void setNewLoginInfo(String user, String pass)
    {
        this.loginInfo.put(user, pass);
    }
  
    Boolean isUserInHash(String user)
    {
        return loginInfo.containsKey(user);
    }
    
    Boolean isPassInHash(String pass)
    {
        return loginInfo.containsValue(pass);
    }
    
    void setFileStringHTML(String string)
    {
        this.fileInHTML = string;
    }
    
    String getFileInHTML()
    {
        return fileInHTML;
    }
    
    void writeToFile()
    {
       // System.out.println(loginInfo);
        Writer writer;
        
        try {
                writer = new FileWriter("src/LoginInfo.txt");
                
                for(Map.Entry<String,String> entry : loginInfo.entrySet())
                {
                    writer.append(entry.getKey() + ":" + entry.getValue());
                    writer.append("\n");
                }
                
                writer.close();
            
        } catch (IOException ex) {
            Logger.getLogger(NoteModel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
