/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9noteslist;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.web.HTMLEditor;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *  User can edit a note, implements an interface that has save, and delete functions
 * 
 * References:
 *      Lines: 94-98 & 129-133 : https://code.makery.ch/blog/javafx-dialogs-official/
 * 
 * @author rthak
 */
public class EditNoteFXMLController extends Switchable implements Initializable {

    @FXML
    AnchorPane editRoot;
    
    @FXML
    private Button returnButton;
    
    @FXML
    private Button saveButton;
    
    @FXML
    private Button deleteButton;
    
    @FXML
    private Button helpButton;
    
    @FXML
    VBox editorContainer;
    
    @FXML
    TextField titleField;
    
    @FXML
    HTMLEditor editor;
    
    NoteModel note;
    
    Boolean hasFileBeenSavedCheck = false;
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        LoginPageFXMLController controller = (LoginPageFXMLController) getControllerByName("LoginPageFXML");
        note = controller.note;  
    }    
    
    @FXML
    void handleDelete(ActionEvent event)
    {
        if (note.getFile() == null)
        {
            System.out.println("No file to be deleted");
            return;
        }
        
        Alert a = new Alert(Alert.AlertType.CONFIRMATION);
        a.setHeaderText("Are you sure you want to delete this file?");
        a.setContentText("Please make sure you would like to delete this file. It cannot be recovered.");
        a.setTitle("Confim Deletion");
        
        ButtonType delete = new ButtonType("Delete");
        ButtonType cancel = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        a.getButtonTypes().setAll(delete, cancel);
        
        Optional<ButtonType> result = a.showAndWait();
        
        
        if (result.get() == delete)
        {
            note.deleteNote();
            note.setFile(null);
            exitEditNote();
        }
        else
        {
            System.out.println("File not deleted");
        }
    }
    
    @FXML
    void handleSave(ActionEvent event)
    {
        saveFunction();
    }
    
    @FXML
    void handleReturn(ActionEvent event)
    {
        if(hasFileBeenSavedCheck == false)
        {
            Alert a = new Alert(Alert.AlertType.WARNING);
            a.setHeaderText("You haven't saved your Note!");
            a.setContentText("Please make sure you have saved this Note, otherwise all changes will be discarded");
            a.setTitle("Confim Return");
        
            ButtonType save = new ButtonType("Save");
            ButtonType noSave = new ButtonType("Don't Save", ButtonBar.ButtonData.CANCEL_CLOSE);
            a.getButtonTypes().setAll(save, noSave);
        
            Optional<ButtonType> result = a.showAndWait();
        
        
            if (result.get() == noSave)
            {
                exitEditNote();
            }
        
            else
            {
                saveFunction();
                exitEditNote();
            }
        } 
        
        else
        {
            exitEditNote();
        }
    }
    
    @FXML
    private void handleHelp(ActionEvent event)
    {
        Switchable.switchTo("HelpFXML");
        HelpFXMLController controller = (HelpFXMLController) getControllerByName("HelpFXML");
        controller.key = 3;
    }
    
    private void saveFunction()
    {
        Stage stage = (Stage) root.getScene().getWindow();
        FileChooser fileChooserSave = new FileChooser(); 
        fileChooserSave.setInitialDirectory(note.getSelectedDirectory());
        fileChooserSave.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        
        fileChooserSave.setInitialFileName(titleField.getText());
        File file = fileChooserSave.showSaveDialog(stage);
        
        FileWriter writer; 
        
        if(file != null)
        {
            
            try { 
                
                writer = new FileWriter(file);
                writer.write(editor.getHtmlText());
                writer.close();

            } catch (IOException ex) {
                Logger.getLogger(MenuFXMLController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (Exception ex){
                Logger.getLogger(MenuFXMLController.class.getName()).log(Level.SEVERE, null, ex);
            }
        
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("FILE SAVED");
            alert.setContentText("File Successfully Saved!");
            alert.show();
            
            hasFileBeenSavedCheck = true;
        }
    }
    
    private void exitEditNote()
    {
        titleField.setText("");
        editor.setHtmlText("");
        hasFileBeenSavedCheck = false;
        Switchable.switchTo("MenuFXML");
    }
}
