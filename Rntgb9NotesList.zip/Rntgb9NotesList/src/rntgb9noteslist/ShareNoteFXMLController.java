/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9noteslist;

// using SendGrid's Java Library
// https://github.com/sendgrid/sendgrid-java
import com.sendgrid.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 * 
 * References: 
 *      Lines 83 - 102 : https://sendgrid.com/docs/for-developers/sending-email/v3-java-code-example/
 * 
 * @author rthak
 */
public class ShareNoteFXMLController extends Switchable implements Initializable {

    @FXML
    private Button helpButton;
    
    @FXML
    private Button returnButton;
    
    @FXML
    private Button sendEmailButton;
    
    @FXML
    private TextField reciever;         //the email address of who they want to sent the email to 
    
    /**
     * Initializes the controller class.
     */
    @Override
    
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    private void handleHelp(ActionEvent event)
    {
        Switchable.switchTo("HelpFXML");
        HelpFXMLController controller = (HelpFXMLController) getControllerByName("HelpFXML");
        controller.key = 5;
    }
    
    @FXML
    private void handleReturn(ActionEvent event)
    {
        Switchable.switchTo("ReadNoteFXML");
    }
    
    @FXML
    private void handleSend(ActionEvent event) throws IOException
    {   
        ReadNoteFXMLController controller = (ReadNoteFXMLController) getControllerByName("ReadNoteFXML");
        String sendTo = reciever.getText();
        String subjectString = controller.titleField.getText();
        
        if(sendTo.equals("") || !sendTo.contains("@"))
        {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setHeaderText("Missing Sender");
            alert.setContentText("Please enter in a valid email address");
            alert.show();
            return;
        }
        
        Email from = new Email("rntgb9@mail.missouri.edu");                     //Cannot change this email address
        String subject = subjectString;
        Email to = new Email(sendTo);                                         
        Content content = new Content("text/html", controller.noteArea.getHtmlText());
        
        Mail mail = new Mail(from, subject, to, content);

        SendGrid sg = new SendGrid("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");
        Request request = new Request();
        try {
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());
            Response response = sg.api(request);
            System.out.println(response.getStatusCode());
            System.out.println(response.getBody());
            System.out.println(response.getHeaders());
        } catch (IOException ex) {
            throw ex;
        }
        
        Alert sent = new Alert(AlertType.INFORMATION);
        sent.setHeaderText("Message Sent!");
        sent.setContentText("Note was successfully sent to : " + sendTo);
        sent.show();
    }
}
