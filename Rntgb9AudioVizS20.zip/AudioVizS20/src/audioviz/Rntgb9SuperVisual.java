/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audioviz;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import static java.lang.Integer.min;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.PerspectiveCamera;
import javafx.scene.effect.Reflection;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Box;
import javafx.geometry.Bounds;
import javafx.scene.shape.CullFace;
import javafx.scene.shape.DrawMode;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;

/**
 *
 * @author rthak
 */
public class Rntgb9SuperVisual implements Visualizer{
    private final String name = "Rntgb9 Super Visual";
    
    private Integer numOfBands;
    private AnchorPane vizPane;
    
    private String vizPaneInitialStyle = "";
    
    private final Double bandHeightPercentage = 1.3;
    private final Double minBoxHeight = 75.0;
    
    private Double width = 0.0;
    private Double height = 0.0;
    
    private Double bandWidth = 0.0;
    private Double bandHeight = 0.0;
    private Double halfBandHeight = 0.0;
    
    private final Double startHue = 260.0;
    
    private Image image = new Image(getClass().getResourceAsStream("Rntgb9NightSky.jpg"));
    private BackgroundImage backgroundimage = new BackgroundImage(image, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
    private Background background = new Background(backgroundimage);
  
    private Box[] boxes;
            
    public Rntgb9SuperVisual() {
    }
    
    @Override
    public String getName() {
        return name;
    }
    
    @Override
    public void start(Integer numBands, AnchorPane vizPane) {
        end();
     
        vizPaneInitialStyle = vizPane.getStyle();
        
        this.numOfBands = numBands;
        this.vizPane = vizPane;
        
        height = vizPane.getHeight();
        width = vizPane.getWidth();
        
        Rectangle clip = new Rectangle(width, height);
        clip.setLayoutX(0);
        clip.setLayoutY(0);
        vizPane.setClip(clip);
     
        vizPane.setBackground(background);
        
        bandWidth = width / numBands;
        bandHeight = height * bandHeightPercentage;
        halfBandHeight = bandHeight / 2;
        boxes = new Box[numBands];
                        
        for (int i = 0; i < numBands; i++) {
            Box box = new Box();
            box.setWidth(bandWidth*0.75);
            box.setHeight(bandWidth/2);
            box.setDepth(bandWidth/2);
            box.setTranslateX(bandWidth/2 + bandWidth*i);
            box.setTranslateY(height/2);
            box.setTranslateZ(height/2);
            box.setDrawMode(DrawMode.FILL);
            box.setMaterial(new PhongMaterial(Color.rgb(30, 11, 77)));
            box.setRotationAxis(Rotate.Y_AXIS);
            vizPane.getChildren().add(box);
            boxes[i] = box;
        }

    }
    
    @Override
    public void end() {
         if (boxes != null) {
             for (Box box : boxes) {
                 vizPane.getChildren().remove(box);
             }
            boxes = null;
            vizPane.setBackground(null);
            vizPane.setClip(null);
            vizPane.setStyle(vizPaneInitialStyle);
        } 
    }
    
    @Override
    public void draw(double timestamp, double lenght, float[] magnitudes, float[] phases) {
        if (boxes == null) {
            return;
        }
                
        Integer num = min(boxes.length, magnitudes.length);
                                
        for (int i = 0; i < num; i++)
        {
            boxes[i].setHeight((((60.0 + magnitudes[i])/50.0) * halfBandHeight + minBoxHeight));
            boxes[i].setMaterial(new PhongMaterial(Color.hsb(startHue - (magnitudes[i] * -6.0), 1.0, 1.0, 1.0)));
            boxes[i].setRotate(phases[i] * 150);
            //boxes[i].setTranslateY((height/2)+(1.25*i));
            if (numOfBands == 100)
            {
                if(timestamp < 180)
                {
                    if(i%2 == 0)
                    {
                        boxes[i].setTranslateY((height/2)+(i*0.009*timestamp));
                    }
                    else
                    {
                        boxes[i].setTranslateY((height/2)-(i*0.009*timestamp));
                    }            
                }
            }
            else if (numOfBands == 60)
            {
                if(timestamp < 265)
                {
                    if(i%2 == 0)
                    {
                        boxes[i].setTranslateY((height/2)+(i*0.01*timestamp));
                    }
                    else
                    {
                        boxes[i].setTranslateY((height/2)-(i*0.01*timestamp));
                    }
                }
            }
            else if (numOfBands == 40)
            {
                if(timestamp < 200)
                {
                    if(i%2 == 0)
                    {
                        boxes[i].setTranslateY((height/2)+(i*0.02*timestamp));
                    }
                    else
                    {
                        boxes[i].setTranslateY((height/2)-(i*0.02*timestamp));
                    }
                }
            }
            else if (numOfBands <= 16)
            {
                if(timestamp < 330)
                {
                    if(i%2 == 0)
                    {
                        boxes[i].setTranslateY((height/2)+(i*0.03*timestamp));
                    }
                    else
                    {
                        boxes[i].setTranslateY((height/2)-(i*0.025*timestamp));
                    }
                }
            }
            System.out.println(timestamp);
        }
    }
}

