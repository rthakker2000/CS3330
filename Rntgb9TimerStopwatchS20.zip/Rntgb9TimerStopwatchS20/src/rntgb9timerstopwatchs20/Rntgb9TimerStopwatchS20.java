/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9timerstopwatchs20;

import static java.lang.Math.abs;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * References: 
 *      Lines 166 & 189-199 : https://gist.github.com/SatyaSnehith/167779aac353b4e79f8dfae4ed23cb85
 *      Lines 217-219       : https://www.geeksforgeeks.org/javafx-alert-with-examples
 * 
 * @author rthak
 */
public class Rntgb9TimerStopwatchS20 extends Application {
    //animation
    public Timeline timeline;
    public KeyFrame keyframe;
    
    //images on display
    public ImageView dialImageView;
    public ImageView handImageView;
    
    //stopwatch algorithm
    public double secondsElapsed = 0.00;
    public double tickTimeInSeconds = 0.01;                                     
    public double angleDeltaPerSeconds = 6.0;
    
    public int recordCounter = 0;                                               //counts # of times record has been pressed
    
    //timer variables
    public int min = 0;
    public int sec = 0;
    public int centisec = 0;
    
    //lap time, first click
    public int lapmin1 = 0;
    public int lapsec1 = 0;
    public int lapcentisec1 = 0;
    
    //lap time, second click
    public int lapmin2 = 0;
    public int lapsec2 = 0;
    public int lapcentisec2 = 0;
    
    //lap time total, difference between the 2 clicks
    public int lapmin = 0;
    public int lapsec = 0;
    public int lapcentisec = 0;
        
    //font setting
    public String fontStyle = "Arial";
    
    @Override
    public void start(Stage primaryStage) {
        
    primaryStage.setTitle("StopWatch");
        
        StackPane root = new StackPane();                                       //setting up the root
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(10, 25, 10, 25));
        
        dialImageView = new ImageView();                                        //Adding Analog Clock to root
        handImageView = new ImageView();
        root.getChildren().addAll(dialImageView, handImageView);
        
        Image dialImage = new Image(getClass().getResourceAsStream("clockface.png"));
        Image handImage = new Image(getClass().getResourceAsStream("hand.png"));
                
        dialImageView.setImage(dialImage);
        handImageView.setImage(handImage);
        
        HBox buttonControls = new HBox(20);                                     //Adding buttons to root
        Button startStop = new Button("Start");                                          //This one will be both Start and Stop
        Button recordReset = new Button("Record");                                      //This one will be both Record and Reset
        startStop.setMaxWidth(100);                                   
        recordReset.setMaxWidth(100);
        buttonControls.setAlignment(Pos.BOTTOM_CENTER);
        buttonControls.getChildren().addAll(recordReset, startStop);
        
        VBox digitalDisplay = new VBox();                                       //Adding labels for digital display to root
        digitalDisplay.setPadding(new Insets(0, 0, 10, 0));
        
        Label timeLabel = new Label("00:00.00");                                //Digital Time Label
        timeLabel.setMinSize(80, 20);
        timeLabel.setFont(Font.font(fontStyle, FontWeight.EXTRA_BOLD, 24));

        Label timerLabel = new Label("Timer 60.00");                            //Timer Label
        timerLabel.setMinSize(80, 20);
        timerLabel.setFont(Font.font(fontStyle, FontWeight.NORMAL, 18));
        
        Label lapLabel = new Label("Lap --:--:--");                             //Lap Label 
        lapLabel.setMinSize(80, 20);
        lapLabel.setFont(Font.font(fontStyle, FontWeight.NORMAL, 18));
        
        digitalDisplay.setAlignment(Pos.TOP_CENTER);
        digitalDisplay.getChildren().addAll(timeLabel, timerLabel, lapLabel);
        root.getChildren().addAll(digitalDisplay, buttonControls);
        
        startStop.setOnAction((ActionEvent event) -> {
            if(isRunning())                                                     //button pressed to stop animation
            {
                timeline.pause();
                startStop.setText("Start");                                     
                recordReset.setText("Reset");
            }
            
            else                                                                //button pressed to play animation
            {
                timeline.play();
                startStop.setText("Stop");                                      
                recordReset.setText("Record");
            }
        });
        
        recordReset.setOnAction((ActionEvent event) -> {
            if(handImageView.getRotate() == 0.0)                                //Makes sure button stays "Record" until Start is pressed
            {
                recordReset.setText("Record");
            }
            else if(isRunning())                                                //allows record to be pressed during animation
            {
                recordReset.setText("Record");
                if(recordCounter%2 == 1)                                        //for odd numbered clicks, set the times for current min, sec, and centisec
                {
                    lapmin1 = min;
                    lapsec1 = sec;
                    lapcentisec1 = centisec;
                }
                else                                                            //for even numbered clicks, set the times for current min sec, and centisec
                {
                    lapmin2 = min;
                    lapsec2 = sec;
                    lapcentisec2 = centisec;
                }
                lapmin = abs(lapmin2 - lapmin1);                                //find the difference between click times
                lapsec = abs(lapsec2 - lapsec1);
                lapcentisec = abs(lapcentisec2 - lapcentisec1);
                lapLabel.setText("Lap " + (((lapmin/10) == 0) ? "0" : "") + lapmin + ":" + (((lapsec/10 == 0) ? "0" : "") + lapsec + "." + (((lapcentisec/10) == 0) ? "0" : "")) + lapcentisec++);
                recordCounter++;
            }
            else                                                                //When animation is paused, clicked Reset to reset everything to initial values
            {
                handImageView.setRotate(0.0);
                secondsElapsed = 0;
                min = 0;
                sec = 0;
                centisec = 0;
                timeLabel.setText("00:00.00");
                timerLabel.setText("Timer 60.00");
                lapLabel.setText("Lap --:--:--");
                recordReset.setText("Record");
            }
        });
                   
        keyframe = new KeyFrame(Duration.millis(10), (ActionEvent actionEvent) ->{
            
            secondsElapsed += tickTimeInSeconds;                                //sets animation for analog clock
            double rotation = secondsElapsed * angleDeltaPerSeconds;
            handImageView.setRotate(rotation);
            
            if(centisec == 100)                                                 //sets counting bounds for the digital clock
            {
                sec++;
                centisec = 0;
            }
            if(sec == 60)
            {
                min++;
                sec = 0;
            }
            timeLabel.setText((((min/10) == 0) ? "0" : "") + min + ":" + (((sec/10 == 0) ? "0" : "") + sec + "." + (((centisec/10) == 0) ? "0" : "")) + centisec++);
            
            int timerValSec = 59 - sec;                                         //sets the timer value by the values in the digital time clock
            int timerValCentisec = 100 - centisec;
            
            if(min < 1)                                                         //makes sure that the timer only runs for 60 seconds
            {
                timerLabel.setText("Timer " + timerValSec + "." + timerValCentisec);
            }
            else                                                                //stops animation at 60 seconds
            {
                timerLabel.setText("Timer 00.00");
                timeline.pause();
                startStop.setText("Start");                                     
                recordReset.setText("Reset");
            }
            if(timerValSec == 0 && timerValCentisec == 0)                       //sends alert when timer hits 
            {
                Alert a = new Alert(Alert.AlertType.INFORMATION);
                a.setContentText("You have " + recordCounter + " records in 60 seconds");
                a.show();
            }
        });
        
        timeline = new Timeline(keyframe);
        
        timeline.setCycleCount(Animation.INDEFINITE);
        
        double width = dialImage.getWidth();
        double height = dialImage.getHeight();
        
        Scene scene = new Scene(root, width + 50, height + 175);
        primaryStage.setScene(scene);
        
        primaryStage.show();
    }
    
    
    public boolean isRunning()                                                  //this function check to see if animation is running
    {
        if(timeline != null)
        {
            if(timeline.getStatus() == Animation.Status.RUNNING)
            {
                return true;
            }
        }
        
        return false;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
