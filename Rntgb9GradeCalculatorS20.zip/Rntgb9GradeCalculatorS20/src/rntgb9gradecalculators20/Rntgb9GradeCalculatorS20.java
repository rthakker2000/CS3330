/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9gradecalculators20;

import java.text.DecimalFormat;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 * Change score variables to lowercase
 * @author rthak
 * 
 * References:
 *      Lines 40 & 124 : https://mkyong.com/java/java-display-double-in-2-decimal-points/
 *      Lines 141 - 143 : https://www.geeksforgeeks.org/javafx-alert-with-examples/
 *      Line 124 : https://docs.oracle.com/javase/tutorial/uiswing/components/textarea.html
 *      Lines 118 - 120 : https://beginnersbook.com/2013/12/how-to-convert-string-to-double-in-java/
 */
public class Rntgb9GradeCalculatorS20 extends Application {
    
    private static final DecimalFormat DECIMALFORMAT = new DecimalFormat("#.##");     //format for the calculated final score
    
    public String title = "Grade Calculator";
    
    public int width = 500;
    public int height = 300;
    
    public String fontStyle = "Arial";
    
    @Override
    public void start(Stage primaryStage) {
    
        primaryStage.setTitle(title);
        
        GridPane root = new GridPane();                                         //set up for the root
        root.setAlignment(Pos.CENTER);
        root.setHgap(10);
        root.setVgap(10);
        root.setPadding(new Insets(25, 25, 25, 25));
        
        //root.setGridLinesVisible(true);
        
        Label assignments = new Label("Assignments (40%): ");                   //Creating assignments label
        assignments.setFont(Font.font(fontStyle, FontWeight.NORMAL, 18));
        root.add(assignments, 0, 0);
        
        TextField Score1 = new TextField();                                     //Creating textfield for assignments
        Score1.setPrefWidth(300);
        root.add(Score1, 1, 0);
        
        Label exams = new Label("Exams (40%): ");                               //Creating exams label
        exams.setFont(Font.font(fontStyle, FontWeight.NORMAL, 18));
        root.add(exams, 0, 1);
        
        TextField Score2 = new TextField();                                     //Creating textfield for exams
        Score2.setPrefWidth(300);        
        root.add(Score2, 1, 1);
        
        Label finalProject = new Label("Final Project (20%): ");                //Creating label for finalProject
        finalProject.setFont(Font.font(fontStyle, FontWeight.NORMAL, 18));
        root.add(finalProject, 0, 2);
        
        TextField Score3 = new TextField();                                     //Creating textfield for final project
        Score3.setPrefWidth(300);        
        root.add(Score3, 1, 2);
        
        Label finalScore = new Label("Final Score: ");                          //Creating label for final socre
        finalScore.setFont(Font.font(fontStyle, FontWeight.NORMAL, 18));
        root.add(finalScore, 0, 3);
        
        TextArea FinalScore = new TextArea();                                   //Creating immutable text area for final score
        FinalScore.setPrefWidth(300);
        FinalScore.setPrefRowCount(2);
        FinalScore.setWrapText(true);
        FinalScore.setEditable(false);
        root.add(FinalScore, 1, 3);
        
        HBox buttonControls = new HBox();                                       //Creating Hbox
        buttonControls.setPadding(new Insets(10, 0, 10, 0));
        buttonControls.setSpacing(15);
        
        Button calculate = new Button("Calculate");                             //Creating calculate button
        calculate.setMinWidth(80);
        
        Button fullScore = new Button("Full Score");                            //Creating full score button
        fullScore.setMinWidth(80);
        
        Button clear = new Button("Clear");                                     //Creating clear button
        clear.setMinWidth(80);
        
        Button alert = new Button("Alert");                                     //Creating alert button
        alert.setMinWidth(80);
        
        buttonControls.setAlignment(Pos.BOTTOM_CENTER);                         //Button alignment and adding to root
        buttonControls.getChildren().addAll(calculate, fullScore, clear, alert);
        root.add(buttonControls, 0, 4, 2, 1);
                
        calculate.setOnAction((ActionEvent actionEvent) -> {                    //Action when calculate pressed
            double score1 = Double.parseDouble(Score1.getText());
            double score2 = Double.parseDouble(Score2.getText());
            double score3 = Double.parseDouble(Score3.getText());
            double finalValue;
            
            finalValue = (score1*0.4) + (score2*0.4) + (score3*0.2);
            FinalScore.appendText("My final score should be " + score1 + "*0.4+" + score2 + "*0.4+" + score3 + "*0.2=" + DECIMALFORMAT.format(finalValue));
        });
        
        fullScore.setOnAction((ActionEvent actionEvent) -> {                    //Action when full score pressed
            Score1.setText("100");
            Score2.setText("100");
            Score3.setText("100");
        });
               
        clear.setOnAction((ActionEvent actionEvent) -> {                        //Action when clear pressed
            Score1.clear();
            Score2.clear();
            Score3.clear();
            FinalScore.clear();
        });
        
        alert.setOnAction((ActionEvent actionEvent) -> {                        //Action when alert presseds
            Alert a = new Alert(AlertType.INFORMATION);
            a.setContentText(FinalScore.getText());
            a.show();
        });
        
        Scene scene = new Scene(root, width, height);
        
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
