/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9languagebasicss20;
import java.util.Calendar;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author rthak
 * reference: Lines 7, 32, 34, 35 ; http://www.java2s.com/Tutorial/Java/0040__Data-Type/Getcurrenttimeinformation.htm
 * reference: Line 63 ; https://mkyong.com/java/java-display-double-in-2-decimal-points/
 * reference: Line 80-116 (how to do switch/case) ; https://www.geeksforgeeks.org/switch-statement-in-java/
 * 
 */
public class Rntgb9LanguageBasicsS20 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        char c1 = 'D';
        char c2 = 68;
        
        short qualityScore = 89;
        
        float weight = 154.7f;
        float height = 70.87f;
        
        boolean sunny = true;
        boolean warm = false;
        
        Calendar calendar = Calendar.getInstance();
        
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        
        String greeting = "Hello";
        String myPawPrint = "rntgb9";
        
        if(c1 == c2)                                                        //Comparing 2 chars
        {
            System.out.println(c1 + " and " + c2 +" are the same.");
        }
        
        else
        {
            System.out.println(c1 + " and " + c2 +" are NOT the same.");
        }
        
        if(qualityScore >= 0 && qualityScore <= 60)                         //Finding quality score
        {
            System.out.println("The quality is bad.");
        }
        
        else
        {
            System.out.println("Good quality.");
        }
        
        float bmi = (float)((weight*703)/(height*height));                  //Finding BMI given height & weight
        
        System.out.println("My BMI = " + String.format("%.2f", bmi));
        
        if(sunny && warm)                                                   //Activity based off of weather
        {
            System.out.println("Go hiking.");
        }
        
        else if(warm && !sunny)
        {
            System.out.println("Go barbeque.");
        }
        
        else
        {
            System.out.println("Stay home.");
        }
       
        switch(hour)                                                         //switch case for time of day 
        {
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
                System.out.println("The current time is " + hour + ":" + minute + " in the MORNING");
                break;
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
            case 16:
                System.out.println("The current time is " + hour + ":" + minute + " in the AFTERNOON");
                break;
            case 17:
            case 18:
            case 19:
            case 20:
            case 21:
            case 22:
                System.out.println("The current time is " + hour + ":" + minute + " in the EVENING");
                break;
            case 23:
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
                System.out.println("The current time is " + hour + ":" + minute + " in the NIGHT");
                break;
            default:
                System.out.println("You have the wrong time.");
        }
        
        for(int count = 3; count <= 9; count++)                                   //for loop for numbers divisible by 2
        {
            if(count%2 == 0)
            {
                System.out.println("Count: " + count);
            }
        }
        
        int countDown = 3;
        
        while(countDown > 0)                                                    //Count down from 3 displaying each number w/ while loop
        {
            System.out.println("Count Down: " + countDown);
            countDown--;
        }
        System.out.println("Houston, we have a lift off!");
        
        System.out.println(invokeMe(greeting, myPawPrint));   
    }
    
    public static String invokeMe(String greeting, String myPawPrint)           //invoke me method, call for greeting, pawprint, and date.
    {
        String tempString;
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");
        Date date = new Date();
        
        tempString = greeting + ", my pawprint is " + myPawPrint + " and today's date is " + dateFormat.format(date);
        
        return tempString;
    }
}
