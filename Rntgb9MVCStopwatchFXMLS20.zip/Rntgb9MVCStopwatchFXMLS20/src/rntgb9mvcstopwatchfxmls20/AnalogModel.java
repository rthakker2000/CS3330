/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9mvcstopwatchfxmls20;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author rthak
 */
public class AnalogModel extends AbstractModel {
    
    private double angleDeltaPerSeconds;
    
    public AnalogModel()
    {
        angleDeltaPerSeconds = 6.0;
    }
          
    @Override
    public void updateMonitor() {
        super.updateMonitor();
        updateAnalog(secondsElapsed);
    }
   
    public void updateAnalog(double secondsElapsed){
        double rotation = secondsElapsed * angleDeltaPerSeconds;                //secondsElapsed increased by tickTimeInSeconds in the AbstractModel
        firePropertyChange("Analog", null, rotation);
    }
}
