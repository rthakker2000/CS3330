/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9mvcstopwatchfxmls20;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.util.Duration;

/**
 * References: Used code from in-class example MvcCpuMonitorFXML
 * 
 * @author rthak
 */
public class AbstractModel {                                                    //Model that has all methods/fields used by both the Analog & Digital Models
    
    protected Timeline timeline;
    protected KeyFrame keyFrame;
    
    protected double secondsElapsed;
    protected double tickTimeInSeconds;

    protected PropertyChangeSupport propertyChangeSupport;

    public AbstractModel()
    {
        propertyChangeSupport = new PropertyChangeSupport(this);
        
        secondsElapsed = 0.00;
        tickTimeInSeconds = 0.01;
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(listener);
    }

    protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
        propertyChangeSupport.firePropertyChange(propertyName, oldValue, newValue);
    }
    
    public void setupMonitor() {        
        keyFrame = new KeyFrame(Duration.millis(10), (ActionEvent event) -> {
                updateMonitor(); 
        });
        timeline = new Timeline(keyFrame);
        timeline.setCycleCount(Animation.INDEFINITE);
    }
    
    public void updateMonitor() {
        //applies to both analog and digital, so it's in the superclass
        double secondsElapsed = getSecondsElapsed();
    }
    
    public double getSecondsElapsed()
    {
        return secondsElapsed += tickTimeInSeconds;
    }

    public void start() {
        timeline.play();
    }
    
    public void stop() {
        timeline.pause();
    }
    
    public void reset() {
        timeline.stop();
        secondsElapsed = 0.0;
    }
    
    public Timeline getTimeLine(){
        return timeline; 
    }
    
    public void setTimeLine(Timeline timeline){
        this.timeline = timeline; 
    }
    
    public KeyFrame getKeyFrame(){
        return keyFrame; 
    }
    
    public void setKeyFrame(KeyFrame keyFrame){
        this.keyFrame = keyFrame; 
    }
    
    public double getTickTimeInSeconds(){
        return tickTimeInSeconds; 
    }
    
    public boolean isRunnning(){
        if(timeline != null){
            if(timeline.getStatus() == Animation.Status.RUNNING){
                return true;
            }
        }
        return false;
    }
    
}
