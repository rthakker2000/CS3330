/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9mvcstopwatchfxmls20;

import static java.lang.Math.abs;

/**
 * References: Lines 71 & 102 - https://gist.github.com/SatyaSnehith/167779aac353b4e79f8dfae4ed23cb85
 *
 * @author rthak
 */
public class DigitalModel extends AbstractModel {
    
    private String timerString;
    private String lapString;
    
    public int min = 0;                                                         //time
    public int sec = 0;
    public int centisec = 0;
    
    public int recordCounter = 0;
    
    private int lapmin1 = 0;                                                    //click 1 of record counter
    private int lapsec1 = 0;
    private int lapcentisec1 = 0;
    
    private int lapmin2 = 0;                                                    //click 2 of record counter
    private int lapsec2 = 0;
    private int lapcentisec2 = 0;
    
    private int lapminTotal = 0;                                                //difference between click 1 and 2
    private int lapsecTotal = 0;
    private int lapcentisecTotal = 0;
        
    public DigitalModel()
    {
        
    }
    
    @Override
    public void updateMonitor()
    {
        super.updateMonitor();                                          
        updateDigital(secondsElapsed);
    }
    
    public void updateDigital(double secondsElapsed)
    {
        String oldString = timerString;
        timerString = getTimerString(secondsElapsed);
        firePropertyChange("Digital", oldString, timerString);
    }
    
    public String getTimerString(double secondsElapsed)
    {
        if(centisec == 100)
        {
            sec++;
            centisec = 0;
        }
        
        if(sec == 60)
        {
            min++;
            sec = 0;
        }
        
        String temp = ((((min/10) == 0) ? "0" : "") + min + ":" + (((sec/10 == 0) ? "0" : "") + sec + "." + (((centisec/10) == 0) ? "0" : "")) + centisec++);
        
        return temp;
    }
    
    public void updateLap()
    {
        String oldString = lapString;
        lapString = getLapString();
        firePropertyChange("Laps", oldString, lapString);
    }
    
    public String getLapString()
    {
        if(recordCounter%2 == 1)                                                //click 1
        {
            lapmin1 = min;
            lapsec1 = sec;
            lapcentisec1 = centisec;
        }
        else                                                                    //click 2
        {
            lapmin2 = min;
            lapsec2 = sec;
            lapcentisec2 = centisec;
        }
        
        lapminTotal = abs(lapmin2 - lapmin1);                                   //difference
        lapsecTotal = abs(lapsec2 - lapsec1);
        lapcentisecTotal = abs(lapcentisec2 -lapcentisec1);
                
        String temp = ("Lap " + recordCounter + ": "+ (((lapminTotal/10) == 0) ? "0" : "") + lapminTotal + ":" + (((lapsecTotal/10 == 0) ? "0" : "") + lapsecTotal + "." + (((lapcentisecTotal/10) == 0) ? "0" : "")) + lapcentisecTotal++);
        
        return temp;
    }
    
    public void addToRecordChart()                                              //sends info of laptime to controller for Record Chart plotting
    {
        double lapTime;
        lapTime = getlapTime(lapminTotal, lapsecTotal, lapcentisecTotal);
        
        firePropertyChange("Record Chart", null, lapTime);
    }
    
    public double getlapTime(int min, int sec, int centisec)                    //Transforms the int variables into 1 value in seconds
    {
        double total;
        
        min = (min*60);
        centisec = (centisec/100);
        
        total = min + sec + centisec;
        
        return total;
    }
    
    public void clearDigital()                                                  //Resets all values
    {
        min = 0;
        sec = 0;
        centisec = 0;
        
        lapmin1 = 0;
        lapsec1 = 0;
        lapcentisec1 = 0;
        
        lapmin2 = 0;
        lapsec2 = 0;
        lapcentisec2 = 0;
        
        lapminTotal = 0;
        lapsecTotal = 0;
        lapcentisecTotal = 0;
        
        recordCounter = 0;
    }
}
