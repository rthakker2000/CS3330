/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rntgb9mvcstopwatchfxmls20;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

/**
 * References: Lines: 77,78,90,101,102,132,133 - https://stackoverflow.com/questions/55381172/how-to-change-color-of-buttons-made-from-scene-builder
 * 
 * @author rthak
 */
public class FXMLDocumentController implements Initializable, PropertyChangeListener{
    
    @FXML
    private Label lapLabel;
    
    @FXML
    private Label digitalTime;
    
    @FXML
    private ImageView hand;
    
    @FXML
    private Button startStopButton;
    
    @FXML
    private Button recordResetButton;
    
    @FXML
    private LineChart<String, Number> lineChart;
        
    @FXML
    private CategoryAxis xAxis;
            
    @FXML
    private NumberAxis yAxis;
                
    @FXML
    private XYChart.Series<String, Number> series;

    AnalogModel analog; 
    DigitalModel digital;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        series = new XYChart.Series();                                          //initialize Record chart
        lineChart.getData().add(series);
        
        analog = new AnalogModel();                                             //initialize & set up Analog & Digital Models
        digital = new DigitalModel();
        
        analog.setupMonitor();
        digital.setupMonitor();
        
        hand.setRotate(0);
        digitalTime.setText("--:--.--");
        lapLabel.setText("Lap -: --:--.--");
        
        startStopButton.setStyle("-fx-background-color: #13ea6b");      
        recordResetButton.setStyle("-fx-background-color: #5dbcd2");
        
        analog.addPropertyChangeListener(this);
        digital.addPropertyChangeListener(this);
    }  

    @FXML
    public void startStopMonitor(ActionEvent event) {
        if ( !(analog.isRunnning()) || !(digital.isRunnning()))                  //if program is not running & start button is pressed
        {
            analog.start();
            digital.start();
            startStopButton.setStyle("-fx-background-color: #f53f3f");
            startStopButton.setText("Stop");
            recordResetButton.setText("Record");
            recordResetButton.setStyle("-fx-background-color: #5dbcd2");
        } 
        
        else                                                                     //if program is running and stop button is pressed
        {
            analog.stop();
            digital.stop();
            startStopButton.setText("Start");
            recordResetButton.setText("Reset");
            startStopButton.setStyle("-fx-background-color: #13ea6b");
            recordResetButton.setStyle("-fx-background-color: #c9a2e8");
        }
    }
    
    @FXML
    public void recordResetMonitor(ActionEvent event) {
        
        if(hand.getRotate() == 0.0)                                             //keeps text constant if program isn't running
        {
            recordResetButton.setText("Record");
        }
        else if(analog.isRunnning())                                            //if program is running and Record is pressed
        {
            recordResetButton.setText("Record");
            digital.recordCounter++;
            digital.updateLap();
            digital.addToRecordChart();
        }
        else                                                                    //if program is not running and Reset is pressed
        {
            hand.setRotate(0.0);
            analog.reset();
            
            digital.reset();                                                    //resets digital values, including lapLabel values
            digital.clearDigital();
            
            digitalTime.setText("--:--:--.--");
            lapLabel.setText("Lap -: --:--:--.--");
            recordResetButton.setText("Record");
            
            startStopButton.setStyle("-fx-background-color: #5dbcd2");
            recordResetButton.setStyle("-fx-background-color: #5dbcd2");
       
            series.getData().clear();                                           //Resets chart so program can be run again w/out initialization()
            lineChart.getData().clear();
            series = new XYChart.Series();
            lineChart.getData().add(series);
        }
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {                       //handles firePropertyChange events
        if(evt.getPropertyName().equals("Analog"))
        {
             hand.setRotate((double) evt.getNewValue());
        }
        else if(evt.getPropertyName().equals("Digital"))
        {
            digitalTime.setText(evt.getNewValue().toString());
        }
        else if(evt.getPropertyName().equals("Laps"))
        {
            lapLabel.setText(evt.getNewValue().toString());
        }
        else if(evt.getPropertyName().equals("Record Chart"))
        {
            series.getData().add(new XYChart.Data(Integer.toString(digital.recordCounter), evt.getNewValue()));
        }
    }
}
